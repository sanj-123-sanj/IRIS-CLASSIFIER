from flask import Flask, request, jsonify, render_template
import joblib
import pandas as pd

app = Flask(__name__)

# Load the model
model = joblib.load("decision_tree_model.joblib")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    input_features = [data['SepalLength'], data['SepalWidth'], data['PetalLength'], data['PetalWidth']]
    prediction = model.predict([input_features])[0]
    return jsonify({'prediction': prediction})

if __name__ == "__main__":
    app.run(debug=True)
