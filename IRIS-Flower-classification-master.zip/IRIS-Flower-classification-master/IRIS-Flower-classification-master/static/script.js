document.getElementById('prediction-form').addEventListener('submit', function(e) {
    e.preventDefault();
    let SepalLength = document.getElementById('SepalLength').value;
    let SepalWidth = document.getElementById('SepalWidth').value;
    let PetalLength = document.getElementById('PetalLength').value;
    let PetalWidth = document.getElementById('PetalWidth').value;

    fetch('/predict', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            SepalLength: SepalLength,
            SepalWidth: SepalWidth,
            PetalLength: PetalLength,
            PetalWidth: PetalWidth
        })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('result').textContent = `Prediction: ${data.prediction}`;
    });
});
